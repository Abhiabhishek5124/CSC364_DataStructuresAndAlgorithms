import java.io.File;
import java.io.FileNotFoundException;
import java.util.PriorityQueue;
import java.util.Scanner;


public class Driver5 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

//        Prompt user for File path and read their response.
        System.out.print("Enter file path: ");
        String filePath = input.nextLine();

        File file= new File(filePath);
        try {
            Scanner scanner = new Scanner(file);
            int numVertices = scanner.nextInt();
            int numEdges = scanner.nextInt();

            UnionFind uf = new UnionFind(numVertices);
            PriorityQueue<EdgeNode> pq = new PriorityQueue<>();

            for (int i = 0; i < numEdges; i++) {
                int vertex1 = scanner.nextInt();
                int vertex2 = scanner.nextInt();
                int weight = scanner.nextInt();
                EdgeNode edge = new EdgeNode(vertex1, vertex2, weight);
                pq.add(edge);
            }

            int cost = 0;

            while (!pq.isEmpty() && uf.Size() > 1) {

                // Get minimum edge E from PriorityQueue object
                EdgeNode minEdge = pq.poll();
                int x = minEdge.getVertex1();
                int y = minEdge.getVertex2();
                int w= minEdge.getWeight();
                if (uf.Find(x) != uf.Find(y)) {
                    System.out.println(x +" "+ y + " Weight:"+ w );

                   // increment a KruskalCost with edge E’s weight.
                    cost += minEdge.getWeight();
                    uf.Union(x, y);
                }
            }
            System.out.println();

            //Print out cost of MCST
            System.out.println("Kruskal's Algorithm Cost : " + cost);

        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }

    }
}
