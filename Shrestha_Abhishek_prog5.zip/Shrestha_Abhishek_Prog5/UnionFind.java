public class UnionFind {
    protected int[] parent;    //  array that holds/represents the subsets

    public UnionFind(int size) {
        // create subsets so each element 1-(size-1) are in their own sets
        parent = new int[size];
        for (int i = 0; i < size; i++) {
            parent[i] = i;
        }
    }

    public int Find(int x) {
        // compress the paths as we seek out the root
        // so that, now, all members point to root
        if (parent[x] != x) {
            parent[x] = Find(parent[x]);
        }
        return parent[x];
    }

    public void Union(int x, int y)  {
        // find which subset x is in


        int rootX = Find(x);

        // find which  subset  y is in
        int rootY = Find(y);

        // if the sets are NOT the same, then join set x into set y
        if (rootX != rootY) {
            parent[rootX] = rootY;
        }
    }

    public int Size() { // number of subsets
        // just count the roots found in the parent[ ] and return that count
        int count = 0;
        for (int i = 0; i < parent.length; i++) {
            if (parent[i] == i) {
                count++;
            }
        }
        return count;
    }
} // end class
