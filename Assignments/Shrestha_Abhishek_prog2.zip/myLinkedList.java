public class myLinkedList  {
    protected  Node Head;
    protected int  Size;
    public  myLinkedList( )    // default constructor
    {
        Head = null;
        Size = 0;
    }
    public void setHead(Node val) {
        Head=val;
    }

    public Node getHead() {
        return Head;
    }

    public void setSize(int Size) {
        this.Size = Size;
    }

    public int getSize() {
        return Size;
    }

    public void insertEmpty(Node n) {
            n.setNext(n);
            n.setPrev(n);
            Head = n;  // set Head reference to the new node
            Size++;  // increment Size of LIST
        }

    public void insertFront( Node  n ){
        Node front= getHead();
//        check if list is empty
        if (isEmpty()){
            insertEmpty(n);
        }

        else{
            n.setPrev(front.getPrev()); //set prev of new node to last node
            n.setNext(front);           //set next of new node to previous head node
            front.getPrev().setNext(n); //set next of last node to new node
            front.setPrev(n);
            setHead(n); // set new node as head as it is in front
            Size++;
        }

    }

    public void insertRear(Node n){
        Node front= getHead();
        if (isEmpty()){
            insertEmpty(n);
        }
        else {
            front.getPrev().setNext(n);
            n.setPrev(front.getPrev());
            n.setNext(front);
            front.setPrev(n);
            Size++;
        }


    }
    public void insertPos( Node n, int pos ){
        Node front= getHead();
        if (isEmpty()){  // check if the node is empty
            insertEmpty(n);
        }
        else if(pos==1){   //check if the  position is 1 . if so we can use the insertFront function
            insertFront(n);}

        else if(pos==Size+1){  //check if the position is 1 more than the size.. if so we can add it at the rear and use the insertRear function
            insertRear(n);
        }
        else if (pos==2) {       // checking if pos = 2. I used this because the logic i made down did not work for pos=2
            n.setPrev(front);
            n.setNext(front.getNext());
            front.getNext().setPrev(n);
            front.setNext(n);
            Size++;

        }
        else{
                for (int i = 0; i < pos-2; i++) {  // if the position is more than 2, this function will help to insert
                    front=front.getNext();
                }
                n.setPrev(front);
                n.setNext(front.getNext());
                front.getNext().setPrev(n);
                front.setNext(n);
                Size++;

            }




    }


//    delete front node
    public int deleteFront( ){
        Node front=getHead();

//        check if the size is 1. if so, we delete the remaining node and set all to all
        if (Size==1){
            front.setNext(null);
            front.setPrev(null);
            setHead(null);
            Size--;
        }

//        if size is greater than 1, changing the next of previous node to next node of the node given in the position and previous of next node to previous node of the given node of the position
        else{
            front.getNext().setPrev(front.getPrev());
            front.getPrev().setNext(front.getNext());
            setHead(front.getNext());
            Size--;

        }
        return front.getData();
    }


//    delete Rear node
    public int deleteRear( ){
        Node front= getHead();
        Node del= front.getPrev();

//        check if size is 1
        if (Size==1){

            front.setNext(null);
            front.setPrev(null);
            setHead(null);

        }
        else{

            front.getPrev().getPrev().setNext(front);
            front.setPrev(front.getPrev().getPrev());
        }
        Size--;
        return del.getData();
    }


//    delete the node from the given position
    public int deletePos( int pos ){
        Node front= getHead();
        Node del=front;

        if(pos==1){
            return deleteFront();
        }
        else if (pos==Size){
            return deleteRear();
        }
        else if (pos==2) {
            del=front.getNext();
            front.setNext(front.getNext().getNext());
            front.getNext().setPrev(front);

            Size--;

        }
        else{
                for (int i = 0; i <=pos-2; i++) {
                    del=del.getNext();
                }

                del.getNext().setPrev(del.getPrev());
                del.getPrev().setNext(del.getNext());

                Size--;

            }
        return del.getData();

    }

//    print the list
    public void printList( ){
        Node front=getHead();

        if (isEmpty()){
            System.out.println("The list is empty");
        }
        else {
            for (int i = 0; i < Size; i++) {
                System.out.println(i + 1 + " : " + front.getData());
                front = front.getNext();
            }
        }
    }

//    function to check if the node is empty
    public boolean  isEmpty( ){
        if (Size==0)
            return true;
        else
            return false;

    }

//    function to get the node from the given position
    public int getItem( int pos ){
        Node front=getHead();
        if (pos==1){
            return front.getData();
        }
        for (int i = 0; i <=pos-2; i++) {
            front=front.getNext();
        }
        return front.getData();
    }




}   // end myLinkedList class