import java.io.File;
import java.io.FileNotFoundException;

import java.util.Scanner;


public class Driver7 {
    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);
        System.out.print("Please enter path to file : ");
        File file=new File(input.nextLine());

        HashTable ht= new HashTable();
        try{
            Scanner scanner =new   Scanner(file);
            int N= scanner.nextInt();
            for (int i = 0; i < N; i++) {
                String string= scanner.next();
                System.out.println("String == "+string);
                ht.insertWord(string);
                System.out.println();
            }
            System.out.println("Total Collisions Hash #1 : "+ ht.getCollisions1());
            System.out.println();
            System.out.println("Total Collisions Hash #2 : "+ht.getCollisions2());

        }
        catch (FileNotFoundException e){
            System.out.println("File not found");
        }
    }
}
