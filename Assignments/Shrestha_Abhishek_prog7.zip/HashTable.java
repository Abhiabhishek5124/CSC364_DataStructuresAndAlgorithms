
import java.util.*;


public class HashTable {


    private static final int size=59;
    private List<String>[] hashTable1= new ArrayList[size];
    private List<String>[] hashTable2= new ArrayList[size];
    private int collisions1;
    private int collisions2;


    public HashTable(){
        for (int i = 0; i < 59; i++) {
            hashTable1[i]=new ArrayList<>();
            hashTable2[i]=new ArrayList<>();

        }
        collisions1=0;
        collisions2=0;
    }

    private int hashFunction1(String string){
        int sum=0;
        for (int i = 0; i < string.length(); i++) {
            sum+=string.charAt(i);

        }
        return sum;
    }

    private int hashFunction2(String string) {
        int[] bit = new int[8];

//        bit 0
        bit[0] = (string.length() % 2 == 0) ? 0 : 1;

//        bit 1
        switch (string.toUpperCase().charAt(0)) {
            case 'A':
            case 'E':
            case 'I':
            case 'O':
            case 'U':
                bit[1] = 1;
                break;
            default:
                bit[1] = 0;
                break;
        }

//        bit 2

        int asc_sum = hashFunction1(string);
        bit[2] = (asc_sum % 2 == 0) ? 0 : 1;

//        bit 3
        boolean[] charSet = new boolean[128]; // Assuming ASCII characters

        for (int i = 0; i < string.length(); i++) {
            int val = string.charAt(i);
            if (charSet[val]) {
                bit[3] = 1;// symbol is repeated
                break;
            } else {
                bit[3] = 0; // symbol is not repeated
            }
            charSet[val] = true;
        }


//        bit 4
        bit[4] = ((string.charAt(0) + string.charAt((string.length() - 1) / 2) +string.charAt(string.length() - 1)) % 2 == 0) ? 0 : 1;

//        bit 5
        for (int i = 0; i < string.length(); i++) {
            if (string.charAt(i)>=65 && string.charAt(i)<=90) {
                bit[5] = 1;
                break;
            } else {
                bit[5] = 0;
            }
        }
//        bit 6
        String reverse = new StringBuilder(string).reverse().toString();
        bit[6] = (string.compareTo(reverse) < 0) ? 1 : 0;

//        bit 7
        bit[7] = (string.length() <= 6 ? 1 : 0);

        int sum = 0;
        for (int i = 0; i < 8; i++) {
            sum+=(bit[i]*Math.pow(2,i));
        }


        return sum;
    }




    public void insertWord(String string){
        int hashFunction1= hashFunction1(string);
        int hashFunction2= hashFunction2(string);
        int index1= hashFunction1%size;
        int index2=hashFunction2%size;

//check collision for 1

        if (!hashTable1[index1].contains(string)) {

            if (!hashTable1[index1].isEmpty()){
                collisions1++;
            }
            hashTable1[index1].add(0, string);
        }


//        check collision for 2

        if (!hashTable2[index2].contains(string)) {
            if (!hashTable2[index2].isEmpty()){
                collisions2++;
            }
            hashTable2[index2].add(0, string);
        }


        System.out.println("Hash function #1 : "+ hashFunction1+ " Table position "+index1);
        System.out.println("Hash function #2 : "+ hashFunction2+ " Table position "+index2);

    }

    public int getCollisions1(){
        return collisions1;
    }
    public int getCollisions2(){
        return collisions2;
    }
}


