public class myArrayList {

    int size;
    int[] elements;

    public myArrayList(int length){
        size=0;
        elements = new int[length];
    }
    public myArrayList(){
        this(100);
    }

    void insertFront(int x) {
            if (size == elements.length) {
                System.out.println("LIST IS FULL");
                System.exit(-1);
            } else {
                for (int i = size-1; i>=0 ; i--) {
                    elements[i+1]=elements[i];

                }
                elements[0]=x;
                size++;
            }

    }
    void insertRear(int x){
        if (size== elements.length){
            System.out.println("LIST IS FULL");
            System.exit(-1);
        }else{
            elements[size]=x;
            size++;
        }
    }
    void insertPos( int x, int pos ){
        if (size==elements.length){
            System.out.println("LIST IS FULL");
            System.exit(-2);

        }


        for(int i=size;i>=pos;i--){
            elements[i]=elements[i-1];

        }
        elements[pos-1]=x;
        size++;

    }
    int deleteFront(){
        int del=elements[0];

            for (int i=0; i<size-1;i++){
                elements[i]=elements[i+1];
            }
            size--;
            return del;
        }



    int deleteRear(){
        int val = elements[size - 1];
        size--;
        int[] newData = new int[size];
        for (int i = 0; i < size; i++) {
            newData[i] = elements[i];
        }
        elements = newData;
        return val;
    }
    int deletePos( int pos ){
        if (pos>0 && pos<=size){
            int val=elements[pos-1];
            for (int i = pos;i<size;i++){
                elements[i-1]=elements[i];
            }
            size--;
            return val;
        }else {
            System.out.println("Position does not exist. ");
            return -1;
        }
    }
    void printList() {
        if (size == 0) {
            System.out.println("LIST IS EMPTY");
        } else {
            for (int i = 0; i < size; i++) {
                System.out.println(i+1 + " : " +elements[i]);
            }
        }
    }
    boolean  isEmpty(){
        return true?size==0:false;
    }
    boolean  isFull(){
        return true?size==elements.length:false;
    }

    int getItem( int pos ){
        return elements[pos-1];
    }
    int getSize(){
        return size;
    }




}
