import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.Stack;

public class Driver6 {

    private static final int INF = 100000; // Infinity value for initialization


    public static void main(String[] args) {
        Scanner input= new Scanner(System.in);

//        prompt user to input the path

        System.out.print("Please enter a file name/path : ");
        String filePath= input.nextLine();

        File file = new File(filePath);

        try {
            Scanner scanner = new Scanner(file);
            int numVertices = scanner.nextInt();
            int numEdges = scanner.nextInt();


            // Construct the adjacency matrix from file input
            int[][] graph = new int[numVertices][numVertices];
            for (int i = 0; i < numVertices; i++) {
                for (int j = 0; j < numVertices; j++) {
                    graph[i][j] = INF;
                }
                graph[i][i] = 0;
            }

            for (int i = 0; i < numEdges; i++) {
                int src = scanner.nextInt();
                int dest = scanner.nextInt();
                int weight = scanner.nextInt();
                graph[src][dest] = weight;
            }

            // Initialize dist and prev matrices with the data from graph
            int[][] dist = new int[numVertices][numVertices];
            int[][] prev = new int[numVertices][numVertices];
            for (int i = 0; i < numVertices; i++) {
                for (int j = 0; j < numVertices; j++) {
                    dist[i][j] = graph[i][j];
                    prev[i][j] = i;
                }
            }

            // Implementation of floyd's algorithm
            for (int k = 0; k < numVertices; k++) {
                for (int i = 0; i < numVertices; i++) {
                    for (int j = 0; j < numVertices; j++) {
                        if (dist[i][j] > dist[i][k] + dist[k][j]) {
                            dist[i][j] = dist[i][k] + dist[k][j];
                            prev[i][j] = prev[k][j];
                        }
                    }
                }
            }

            // Prompt user to enter vertices and find shortest path

            while (true) {
                System.out.print("Please enter a pair of vertices for shortest path or -1 -1 to end :");
                int src = input.nextInt();
                int dest = input.nextInt();

                if (src == -1 && dest == -1) {
                    break;
                }

                if (src >= numVertices || dest >= numVertices) {
                    System.out.println("Invalid input! Vertex does not exist.");
                    continue;
                }

                System.out.println("Shortest path from "+src+" to "+dest+ " is distance " + dist[src][dest]);

                // actual path using Path() function
                Stack<Integer> path = Path(prev, src, dest);

                while (!path.isEmpty()) {
                    System.out.print(path.pop() + " ");
                    if(!path.isEmpty()){
                        System.out.print("--> ");
                    }

                }
                System.out.println();
                System.out.println();
            }


        }
        catch (FileNotFoundException e){
            System.out.println("File not found");
        }
    }

//    path method
    private static Stack<Integer> Path(int[][] prev, int u, int v) {
        Stack<Integer> path = new Stack<>();
        path.push(v);
        while (u != v) {
            v = prev[u][v];
            path.push(v);
        }
        return path;
    }

}

