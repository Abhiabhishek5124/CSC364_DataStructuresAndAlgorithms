public class myQueue extends myLinkedList {

//    Constructor for the class.
        public myQueue() {
            super(); // Call the constructor of the parent class.
        }

//        Adds an element to the back of the queue.
        public void enqueue( int v  ) {
            Node node= new Node(v);
            insertRear(node);
        }
        
//      Removes and returns the element at the front of the queue.
        public  int  dequeue(){
            return deleteFront();
        }

//        Returns the value of the element at the front of the queue without removing it.
        public int front () {
            return getItem(1);
        }

//        Returns the value of the element at the back of the queue without removing it.
        public int rear(){
            return getItem(Size);
        }

    }


