public class myDigraph extends myQueue {

    int[][] matrix;
    boolean [] visited;
    myQueue Q;

    // constructor to initialize the matrix and visited array
    public myDigraph(int numv){
        matrix=new int[numv][numv];
        for (int i = 0; i < numv; i++) {
            for (int j = 0; j < numv; j++) {
                matrix[i][j]=-1;
            }
        }
        visited=new boolean[numv];
        Q=new myQueue();
    }

    // method to add edge to the graph
    public void addEdge(int x, int y, int w){
        matrix[x][y]=w;
    }

    // method to clear visited array
    public void clearVisited(){
        for (int i = 0; i <visited.length ; i++) {
            visited[i]=false;
        }
    }

    // method to get visited status of a node
    public boolean getVisited(int v){
        return visited[v];
    }

    // recursive method for depth-first search traversal
    public void DFS(int v){
        if (visited[v]) return;
        visited[v]=true;
        System.out.println("Vertex " + v);
        for (int i = 0; i <matrix.length ; i++) {
            if(matrix[v][i]!=-1&&visited[i]==false ) {
                DFS(i);
            }
        }

    }


    //method for breadth-first search traversal
    public void BFS(int v){
        if (visited[v]) return;
        visited[v] =true;
        System.out.println("Vertex " + v);
        for (int i = 0; i <matrix.length ; i++) {
            if(matrix[v][i]!= -1)
                Q.enqueue(i);
        }
        if(!Q.isEmpty()){
            BFS(Q.dequeue());
        }else {
            return;
        }
    }
}
