import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Driver4 {
    public static Scanner inp;
    public static File file;
    public static String fname;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Please enter a path or name of input file : ");
        String filePath = input.nextLine();
            file = new File(filePath);
            try {
                inp = new Scanner(file);
            } catch (Exception E) {
                System.out.println("File not found"); // Print error message if file not found
            }
            String line;
            String[] tokens;
            while (inp.hasNextLine()) {
                line = inp.nextLine();
                tokens = line.split("\\s+");
                int numVertices = Integer.parseInt(tokens[0]); // Convert first token to integer for number of vertices
                int numEdges = Integer.parseInt(tokens[1]); // Convert second token to integer for number of edges
                myDigraph graph = new myDigraph(numVertices); // Create new myDigraph object with specified number of vertices

                for (int i = 0; i < numEdges; i++) { // Loop through each edge
                    line = inp.nextLine();
                    tokens = line.split("\\s+");
                    int x = Integer.parseInt(tokens[0]);
                    int y = Integer.parseInt(tokens[1]);
                    int w = Integer.parseInt(tokens[2]);

                    graph.addEdge(x, y, w); // Add edge to graph
                }
                System.out.println();
                System.out.println("*** DEPTH FIRST SEARCH ***");
                System.out.println();
                for (int x = 0; x < numVertices; x++) {
                    if (!graph.getVisited(x)) {
                        graph.DFS(x); // Perform depth-first search on unvisited vertex
                    }
                }
                graph.clearVisited(); // Clear visited vertices for next search

                System.out.println();
                System.out.println();
                System.out.println("###  BREADTH FIRST SEARCH  ###");
                System.out.println();
                for (int x = 0; x < numVertices; x++) {
                    if (!graph.getVisited(x)) {
                        graph.BFS(x);
                    }
                }

            }
        }
    }
//C:\Users\shresthaa5\IdeaProjects\CSC364_program4\src\test.txt