import java.io.File;
import java.util.Scanner;

public class Driver3 {
    public static myLinkedList list;   // altered line for linked list implementation
    public static Scanner  inp;
    public static File f;
    public static String  fname;
    public static void main(String[] args) {


        System.out.print("Please enter a path or name of input file : ");
        inp = new Scanner(System.in);
        fname = inp.nextLine();
        f = new File(fname);
        try {
            inp = new Scanner(f);
        } catch (Exception E) {
            System.out.println("File not found");
        }
        int line;
        int N= inp.nextInt();


        Stack S1= new Stack();
        Stack S2= new Stack();

        for (int i = 0; i < N; i++) {


            line = inp.nextInt();
//loop if stack 1 is empty or not the number of the line is greater than the top number of the stack
            while (!S1.isEmpty() && line>S1.top()){
//                push the number from stack one to stack 2
                S2.push(S1.pop());
            }
            S1.push(line);

            while (!S2.isEmpty()){
                S1.push(S2.pop());
            }


        }

//        print the numbers in ascending order
        System.out.println("SORTED LIST");
        System.out.println("______________");
        int i=1;
        while(!S1.isEmpty()){
            System.out.println(i + " : " + S1.pop());
            i++;

        }





        }

    }

