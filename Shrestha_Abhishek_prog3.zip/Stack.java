
public class Stack extends myLinkedList {



            public Stack() {
                super();
            }

//            check if the stack is empty or not
            public boolean isEmpty () {
                return super.isEmpty();
            }
//push the number into the stack
            public void push ( int x){
                Node node= new Node(x);
                insertRear(node);
            }
//delete the top number of the stack
            public int pop () {
                return deleteRear();
            }
//get the top number of the stack
            public int top () {
                return getItem(getSize());
            }

        }
